<?php
	$conn = new mysqli('localhost:3307', 'root', 'Silismary10', 'db_issm') or die($conn->error);
?>