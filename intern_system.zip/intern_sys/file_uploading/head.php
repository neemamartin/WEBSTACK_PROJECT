<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
			<img class = "pull-left" src="images/logo1.png" width="50" height="50" alt="logo">
		<a href="index.php" class = "navbar-brand">InternMSU</a>
	<div>
</nav>